package cn.grace.pojo;

public class Funs {

    private int funid;
    private String funname;
    private String funurl;

    public int getFunid() {
        return funid;
    }

    public void setFunid(int funid) {
        this.funid = funid;
    }

    public String getFunname() {
        return funname;
    }

    public void setFunname(String funname) {
        this.funname = funname;
    }

    public String getFunurl() {
        return funurl;
    }

    public void setFunurl(String funurl) {
        this.funurl = funurl;
    }
}


